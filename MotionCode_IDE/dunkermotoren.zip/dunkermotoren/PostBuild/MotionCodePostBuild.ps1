﻿################################################################################
### MotionCodePostBuild.ps1                                                  ###
### Version 1.5                                                              ###
### This script takes the .out file from the GNU C Compiler and generates    ###
### the MotionCodeUpgrade.bin file for the upgrader.                         ###
################################################################################

<#
 # Script parameters
 #>
      
 param(
    [string] $parEclipseHome ="C:\temp\Eclipse\eclipse\",
    [string] $parProjDirPath ="C:/temp/workspace/test_MotionCode",
    [string] $parConfigName = "dProCOMotionCode_Debug",
    [string] $parProjName = "test_MotionCode",
    [string] $parMotionCodeLibraryVersion = "00021.02.0",
    [string] $parMotionCodeLibraryVariant = "dProCO",
    [string] $parMotionCodeMaterialNumber = "99999",
    [string] $parMotionCodeMaterialIndex = "0",
    [string] $parMotionCodeVersion =  "0x00000001",
    [string] $parMotionCodeVariant =  "0x00000001",
    [string] $parMotionCodeVariantName ="MotionCode Template")
    
   
    <#
     # Global variables
     #>
    [String] $tempWorkingDirectory = $null
    [bool] $dbg = $false

    #lookup table for variants:
    $libVariants = @{
        'dProCO' = 0
        'dMoveCO' = 0
        'dProPN' = 1
        'dMovePN' = 1
        'dProEC' = 2
        'dMoveEC' = 2
        'dProEI' = 3
        'dMoveEI' = 3
    }


    if  ($dbg -eq $true)
        {
            Write-Host "parEclipseHome:" + $parEclipseHome
            Write-Host "parProjDirPath:" + $parProjDirPath
            Write-Host "parConfigName:" + $parConfigName
            Write-Host "parProjName:" + $parProjName
            Write-Host "parMotionCodeLibraryVersion:" + $parMotionCodeLibraryVersion
            Write-Host "parMotionCodeLibraryVariant:" + $parMotionCodeLibraryVariant
            Write-Host "parMotionCodeMaterialNumber:" + $parMotionCodeMaterialNumber
            Write-Host "parMotionCodeMaterialIndex:" + $parMotionCodeMaterialIndex
            Write-Host "parMotionCodeVersion:" + $parMotionCodeVersion
            Write-Host "parMotionCodeVariant:" + $parMotionCodeVariant
            Write-Host "parMotionCodeVariantName:" + $parMotionCodeVariantName
        }


    ################################################################################
    ### Function definitions:                                                    ###
    ################################################################################

    <#
    # This function returns >0 if a industrial ethernet variant is build. For CO return is 0
    #>
    function isGenericLibVariantIE ( [String] $MotionCodeLibraryVariant)
    {
        [int] $isIEVariant = 0
        
        $isIEVariant = $libVariants.Item($MotionCodeLibraryVariant)

        if  ($dbg -eq $true)
        {
            Write-Host "isIEVariant:" +  $isIEVariant
        }
        return $isIEVariant
    }

    <#
    # This function returns the generic libraray variant "dMove" or "dPro". 
    #>
    function getGenericLibVariant ( [String] $MotionCodeLibraryVariant)
    {
        $searchPattern  = "dPro"
        $strLibVariant = ""
        if($MotionCodeLibraryVariant.Contains($searchPattern))
        {
            $strLibVariant = $searchPattern
        }
        $searchPattern = "dMove" 
        if($MotionCodeLibraryVariant.Contains($searchPattern))
        {
            $strLibVariant = $searchPattern
        }
       
        if  ($dbg -eq $true)
        {
            Write-Host "LibVariant:" + $strLibVariant
        }
        return $strLibVariant
    } 
    
    <#
    # This function returns true if a ZIP file was generated for IE variants, and returns fals if ZIP file generation failed
    #>
    function generate_IEUpgraderZipFile(
                              [string] $dunkerToolchainPath,
                              [string] $MotionCodeBinFile,
                              [string] $DestinationPathZipFile
                            )
    {
    $targetBinZipDir="\VAR0"
    $targetBinZipSubDir="\PORT_0"
    $targetBinCompleteZipSubDir=$DestinationPathZipFile+$targetBinZipDir+$targetBinZipSubDir

    try 
    {

    New-Item -Path $targetBinCompleteZipSubDir -ItemType Directory -Force -ErrorAction Stop | Out-Null 
    $7Zip = Join-Path $dunkerToolchainPath ("7-Zip/7z.exe")

    Copy-Item -Path $MotionCodeBinFile -Destination $targetBinCompleteZipSubDir\MoCode.bin -ErrorAction Stop

    $7zarg = "a","-tZip",($DestinationPathZipFile+"\FWUPDATE.ZIP"),($DestinationPathZipFile+$targetBinZipDir),"-mm=LZMA","-md=64k","-mx=5"
    & $7Zip $7zarg
    Remove-Item ($DestinationPathZipFile+$targetBinZipDir) -Recurse 
    Write-Host ""
    Write-Host ""
    Write-Host $ZIPFILE "ZIP file generation SUCCEEDED"
    $ret=$true
    }
    catch 
    {
        Write-Host ""
        Write-Host ""
        Write-Host $ZIPFILE "ZIP file generation FAILED"
        $ret=$false
    }
    return $ret
    }
    

    <#
     # prepareToolchain()
     #
     # This function prepares the toolchain, e. g. creates the temp folder, where the post-build stores its data.
     #>
    function prepareToolchain([String]$dunkerToolchainPath){
        $postBuildPath = Join-Path $dunkerToolchainPath "PostBuild/"
        $global:tempWorkingDirectory = Join-Path $postBuildPath "temp/"
        if (Test-Path $global:tempWorkingDirectory)
        {
            # remove old temp data
            Remove-Item -Path $global:tempWorkingDirectory -Recurse -Force
        }
        New-Item -Path $postBuildPath -Name "temp" -ItemType "directory" -Force
    }
    
    
    <#
     # prepareBinFile1()
     #
     # This function prepares the binary with all crc checksums and the proper format for the download file generator.
     # The bin file is placed in the project output path.
     #>
     function prepareBinFile1([String]$dunkerToolchainPath, [String]$projectPath, [String]$projectName, [String]$MotionCodeLibraryVersion, [String]$MotionCodeLibraryVariant, [String]$binaryFile, [string]$parMotionCodeVersion, [String]$parMotionCodeVariant, [String]$parMotionCodeVariantName){
        $ielfTool = Join-Path $dunkerToolchainPath ('ielftool/ielftool.exe')
        $gdbTool = Join-Path $gcctoolchainPath ('arm-none-eabi-gdb.exe')
    
        $inputFile = Join-Path $projectPath ($projectName + ".out")
        
        $arg_gdb_MotionCodeVersion = ""
        $arg_gdb_MotionCodeVariantName = ""
        $arg_gdb_MotionCodeVariant = ""
        # check input parameters:
        if($parMotionCodeVersion -ne "")      { $arg_gdb_MotionCodeVersion = "-ex `"set info.MotionCodeVersion=$parMotionCodeVersion`"" + " " }
        if($parMotionCodeVariant -ne "")      { $arg_gdb_MotionCodeVariant = "-ex `"set info.MotionCodeVariant=$parMotionCodeVariant`"" + " " }
        if($parMotionCodeVariantName -ne "")  { $arg_gdb_MotionCodeVariantName = "-ex `"set info.MotionCodeVariantName=(\`"$parMotionCodeVariantName\`")`"" + " " }
    
        # 1.1) Modification of MotionCode.out to set MotionCode-version -variant and variantname via gdb
        $arg_gdb = " "+ "-write" +" "+"`"$inputFile`"" +" " + "-batch" + " " + $arg_gdb_MotionCodeVersion + $arg_gdb_MotionCodeVariant + $arg_gdb_MotionCodeVariantName 
        $arg_gdb += "-ex `"p info`"" + " " + "-ex quit"
    
        Start-Process "`"$gdbTool`"" -ArgumentList $arg_gdb  -Wait 
    
        # Modification of MotionCode.out by the following checksums:
        # 1.2) PartionCRC over all sectors. Value will be located in the appropriate location of the partion header. See also the module specification of the MemoryAnalyzer
        $argFill = '--fill 0x00;__flash_start__-__flash_end__'
    
        $inputFile = Join-Path $projectPath ($projectName + ".out")
        $outputFile = $inputFile
        $argChkSum = '--checksum=__checksum__:4,crc32:L;__text_start__-__flash_end__ ' + "`"$inputFile`"" + " " + "`"$outputFile`""
    
        Start-Process "`"$ielfTool`"" -ArgumentList $argFill,$argChkSum -Wait
    
        # 1.3) PartionHeaderCRC: Value will be located in the beginning of the partion header. See also the module specification of the MemoryAnalyzer
        $inputFile = Join-Path $projectPath ($projectName + ".out")
        $outputFile = $inputFile
        $argChkSum = '--checksum=__flash_start__:4,crc32:L;__partitionheader_crc_start__-__partitionheader_crc_end__ ' + "`"$inputFile`"" + " " + "`"$outputFile`""
        Start-Process "`"$ielfTool`"" -ArgumentList $argChkSum -Wait
    
        # 2.) Generate a stripped elf file
        $inputFile = Join-Path $projectPath ($projectName + ".out")
        $outputFile = Join-Path $projectPath ($projectName + ".elf")
        $argStrip = '--strip ' + "`"$inputFile`"" + " " + "`"$outputFile`""
        Start-Process "`"$ielfTool`"" -ArgumentList $argStrip -Wait
    
        # 3.) Generate a binary file
        $inputFile = Join-Path $projectPath ($projectName + ".out")
        $outputFile = $binaryFile
        $arg = '-O binary ' + "`"$inputFile`"" + " " + "`"$outputFile`""
        Start-Process $gcctoolchainPath/arm-none-eabi-objcopy -ArgumentList $arg -Wait
    }
    
    
    <#
     # prepareBinFile()
     #
     # This function prepares the binary with all crc checksums and the proper format for the download file generator.
     # The bin file is placed in the project output path.
     #>
     function prepareBinFile([String]$dunkerToolchainPath, [String]$projectPath, [String]$projectName, [String]$MotionCodeLibraryVersion, [String]$MotionCodeLibraryVariant, [String]$binaryFile){
        $ielfTool = Join-Path $dunkerToolchainPath ('ielftool/ielftool.exe')
        # Modification of MotionCode.out by the following checksums:
        # 1.1) PartionCRC over all sectors. Value will be located in the appropriate location of the partion header. See also the module specification of the MemoryAnalyzer

        $libVariant = getGenericLibVariant($MotionCodeLibraryVariant)
        if($libVariant -eq "dPro")
        {
            $argFill = '--fill 0x00;0x08020000-0x0803FFFF'
        }
        if($libVariant -eq "dMove")
        {
            $argFill = '--fill 0x00;0x08010000-0x0801FFFF'
        }
        $inputFile = Join-Path $projectPath ($projectName + ".out")
        $outputFile = $inputFile

        if($libVariant -eq "dPro")
        {
            $argChkSum = '--checksum=0x08020010:4,crc32:L;0x08020030-0x0803FFFF ' + "`"$inputFile`"" + " " + "`"$outputFile`""
        }
        if($libVariant -eq "dMove")
        {
            $argChkSum = '--checksum=0x08010010:4,crc32:L;0x08010030-0x0801FFFF ' + "`"$inputFile`"" + " " + "`"$outputFile`""
        }
        Start-Process "`"$ielfTool`"" -ArgumentList $argFill,$argChkSum -Wait
    
        # 1.2) PartionHeaderCRC: Value will be located in the beginning of the partion header. See also the module specification of the MemoryAnalyzer
        $inputFile = Join-Path $projectPath ($projectName + ".out")
        $outputFile = $inputFile
        if($libVariant -eq "dPro")
        {
            $argChkSum = '--checksum=0x08020000:4,crc32:L;0x08020004-0x0802002F ' + "`"$inputFile`"" + " " + "`"$outputFile`""
        }
        if($libVariant -eq "dMove")
        {
            $argChkSum = '--checksum=0x08010000:4,crc32:L;0x08010004-0x0801002F ' + "`"$inputFile`"" + " " + "`"$outputFile`""
        }
        Start-Process "`"$ielfTool`"" -ArgumentList $argChkSum -Wait
    
        # 2.) Generate a stripped elf file
        $inputFile = Join-Path $projectPath ($projectName + ".out")
        $outputFile = Join-Path $projectPath ($projectName + ".elf")
        $argStrip = '--strip ' + "`"$inputFile`"" + " " + "`"$outputFile`""
        Start-Process "`"$ielfTool`"" -ArgumentList $argStrip -Wait
    
        # 3.) Generate a binary file
        $inputFile = Join-Path $projectPath ($projectName + ".out")
        $outputFile = $binaryFile
        $arg = '-O binary ' + "`"$inputFile`"" + " " + "`"$outputFile`""
        Start-Process $gcctoolchainPath/arm-none-eabi-objcopy -ArgumentList $arg -Wait
    }
    
    
    <#
     # generateDownloadFile()
     #
     # This function generates the download file and places it in the toolchain upgrader path 
     #
     #>
    function generateDownloadFile([String]$dunkerToolchainPath, [String]$MotionCodeLibraryVersion, [String]$MotionCodeLibraryVariant, [String]$MotionCodeMaterialNumber, [String]$MotionCodeMaterialIndex, [String]$binaryFile){
    
        # get the config xml into the DownloadDFileCreator path
        $downloadFileSettingsFile = Join-Path $dunkerToolchainPath ("MotionCodeLibrary/" + $MotionCodeLibraryVersion + "/" + $MotionCodeLibraryVariant + "/DownloadFileSettings.xml")
        Copy-Item -Path $downloadFileSettingsFile -Destination $global:tempWorkingDirectory
        $downloadFileSettingsFile = Join-Path $global:tempWorkingDirectory "DownloadFileSettings.xml"
    
        # adapt the file with the correct Material Number and Index
        [xml]$downloadFileSettingsXml = get-content $downloadFileSettingsFile
        
        $downloadFileSettingsXml.DownloadCreator.Package.materialNumber = $MotionCodeMaterialNumber
        $downloadFileSettingsXml.DownloadCreator.Package.materialIndex = $MotionCodeMaterialIndex
        $downloadFileSettingsXml.Save($downloadFileSettingsFile)
    
        # get the binary file
        Copy-Item -Path $binaryFile -Destination $global:tempWorkingDirectory
    
        # run the download file generator
        $downloadFileCreatorPath = Join-Path $dunkerToolchainPath "DownloadFileCreator/"
        $downloadFileCreator = Join-Path $downloadFileCreatorPath "/MCPDownloadCreator.exe"
        set-location -Path $downloadFileCreatorPath # this location change is required because of the DDLCompatibilityCheck.xml
        Start-Process "`"$downloadFileCreator`"" -ArgumentList "`"$downloadFileSettingsFile`"" -Wait
    }
    
    <#
     # cleanUpToolchain()
     #
     # This function cleans up the toolchain temporary files and copies the output file to the project path and to the upgrader path
     #>
    function cleanUpToolchain([String]$dunkerToolchainPath, [String]$projPath) {
    
        $binFile = Join-Path $global:tempWorkingDirectory "MotionCodeUpgrade.bin"
        $binFileDestination = $projPath
        $debugParamFile = Join-Path $projPath("../Debug.xml")
        $defaultCSParamFile = Join-Path $projPath("../Default_CustomerSetting.xml")
        $defaultInitParamFile = Join-Path $projPath("../Default_Init.xml")
        $additionalParamDestination = Join-Path $projPath("/MCPUpgrader")
        
        $upgraderLocation = Join-Path $dunkerToolchainPath "Upgrader"
        Copy-Item -Path $binFile -Destination $binFileDestination
        Copy-Item -Path $binFile -Destination $upgraderLocation
        
        Copy-Item -Path $debugParamFile -Destination $additionalParamDestination
        Copy-Item -Path $defaultCSParamFile -Destination $additionalParamDestination
        Copy-Item -Path $defaultInitParamFile -Destination $additionalParamDestination

        # remove the whole temporary path recursively
        Remove-Item -Path $global:tempWorkingDirectory -Recurse -Force
    }
    

    <#
     # generateUpgradeXMLFile()
     #
     # This function generates the Upgrader.exe.config.xml upgrade file for MCP upgrader and places it into the output path /MCPUpgrader
     #
     #>
     function generateUpgradeXMLFile([String]$dunkerToolchainPath, [String]$MotionCodeVersion, [String]$MotionCodeVariant, [String]$MotionCodeMaterialNumber, [String]$MotionCodeMaterialIndex, [String] $binFileUpgrade, [String] $projPath)
     {

        $materialNumberForUpgradeFile = $MotionCodeMaterialNumber;
        $MotionCodeVersionForUpgradeFile = $MotionCodeVersion
        $MotionCodeVariantForUpgradeFile = $MotionCodeVariant
        
        formatMaterialNumberForUpgradeFile([ref]$materialNumberForUpgradeFile)
        formatMotionCodeVersionForUpgradeFile([ref]$MotionCodeVersionForUpgradeFile)
        formatMotionCodeVariantForUpgradeFile([ref]$MotionCodeVariantForUpgradeFile)

        # get the config xml into the DownloadDFileCreator path
        $MCPUpgradeFileSettingsDefaultFileName = "DefaultUpgrader.exe.config"
        $MCPUpgradeFileSettingsFileName = "Upgrader.exe.config"

        $MCPUpgradeFilePath = Join-Path $dunkerToolchainPath "MCPUpgrader/"
        $MCPUpgradeOutputPath = $projPath + "\MCPUpgrader"

        $MCPUpgradeDefaultFileSettingsFile = Join-Path $MCPUpgradeFilePath $MCPUpgradeFileSettingsDefaultFileName
        $outputMCPUpgradeXMLFile = Join-Path $MCPUpgradeOutputPath $MCPUpgradeFileSettingsFileName
        $upgradeTempFileSettingsFile = Join-Path $global:tempWorkingDirectory $MCPUpgradeFileSettingsFileName
        $upgradeMotionCodeBinFile = Join-Path $global:tempWorkingDirectory $binFileUpgrade

        Write-Host ""
        Write-Host "generate upgrade package in "$MCPUpgradeOutputPath" "
        Write-Host ""

        If(test-path $MCPUpgradeOutputPath)
        {
          Remove-Item -Path $MCPUpgradeOutputPath -Recurse -Force
        }

        $MCPUpgradeOutputPath = $projPath + "\MCPUpgrader"
        $isVariantIndustrialEthernet = isGenericLibVariantIE $libVariant
        if($isVariantIndustrialEthernet -gt 0)
        {
            if((generate_IEUpgraderZipFile $dunkerToolchainPath $upgradeMotionCodeBinFile $global:tempWorkingDirectory) -eq $true)
            {
                # for IE variant we want to transfer the zipped file:
                $binFileUpgrade = "FWUPDATE.ZIP"
                $upgradeMotionCodeBinFile = $global:tempWorkingDirectory + $binFileUpgrade
            }
        }
        #copy mcp upgrade path to output directory
        Copy-Item -Path $MCPUpgradeFilePath -Destination $projPath -Recurse -Force

        #copy default xml setting file to temporary directory
        Copy-Item -Path $MCPUpgradeDefaultFileSettingsFile -Destination $upgradeTempFileSettingsFile
       
        
        # adapt the file with the correct Material Number and Index
        [xml]$upgradeFileSettingsXml = get-content $upgradeTempFileSettingsFile
        #fill in the data for both parameterset files and firmware file
        $nodesList = $upgradeFileSettingsXml.selectNodes("//UpgradeFiles/UpgradeFile")
        foreach($el in $nodesList) {
            $nodeType = $el.GetElementsByTagName('Type')
            $name = $nodeType.InnerText
                
            if($name -eq "Firmware")
            {
                $el.FileName = $binFileUpgrade
                $el.materialIndex = $MotionCodeMaterialIndex
                $el.MaterialNumber = $materialNumberForUpgradeFile
                $el.Modules.Module.Variant = $MotionCodeVariantForUpgradeFile
                $el.Modules.Module.Version = $MotionCodeVersionForUpgradeFile 
            }
            elseif($name -eq "ParameterSet")
            {
                $el.MaterialNumber = $materialNumberForUpgradeFile
                if($el.materialIndex -eq "LASTINDEX")  
                {
                    #the last xml file should have the same material index as motion code index
                    $el.materialIndex = $MotionCodeMaterialIndex
                }
            }
            else
            {
                #nothing to change here
            }
            
        }

        $upgradeFileSettingsXml.Save($upgradeTempFileSettingsFile)
        
        #For Industrial Ethernet/EtherCAT change the communication settings:
        if($isVariantIndustrialEthernet -gt 0)
        {
            $NodeCommunication = Select-XML -Xml $upgradeFileSettingsXml -XPath '//Communication'
            $NodeCommunication.Node.RemoveAll()  #remove existing CAN communication node
            if($isVariantIndustrialEthernet -eq 2)
            {
                $CommunicationType="EtherCAT"
                $CommunicationAddress='0'
            }
            else 
            {
                $CommunicationType="IndustrialEthernet"
                $CommunicationAddress='192.168.0.1'
            }
            
            $XMLIndustrialEthernet = $upgradeFileSettingsXml.CreateNode("element",$CommunicationType,"")
            $XML_Node_Adapater = $upgradeFileSettingsXml.CreateElement("Adapter")
            $XMLAddress = $upgradeFileSettingsXml.CreateElement("Address") 

            $XMLIndustrialEthernet.AppendChild($XML_Node_Adapater)
            $XMLIndustrialEthernet.AppendChild($XMLAddress)
            
            #fill settings:
            $XML_Node_Adapater.InnerText = 'Ethernet 3'
            $XMLAddress.InnerText = $CommunicationAddress
            
            $NodeCommunication.Node.AppendChild($XMLIndustrialEthernet)
            $upgradeFileSettingsXml.Save($upgradeTempFileSettingsFile)
        }
    
        # copy modified xml file to output folder
        Copy-Item -Path $upgradeTempFileSettingsFile -Destination $outputMCPUpgradeXMLFile
        Copy-Item -Path $upgradeMotionCodeBinFile -Destination $MCPUpgradeOutputPath
    }
    
    
    <#
     # formatMaterialNumberForUpgradeFile()
     #
     # This function check the materialnumber for the upgradefile: 
     # If materialnumber is less or equal 5 digits long, add "00000." 
     #
     #>
    function formatMaterialNumberForUpgradeFile([ref]$materialNumberForUpgradeFile)
    {
        if($materialNumberForUpgradeFile.Value.length -le 5)
        {
            $materialNumberForUpgradeFile.Value = "00000."+$materialNumberForUpgradeFile.Value
        }
    }

   
    <#
     # formatMotionCodeVersionForUpgradeFile()
     #
     # This function formats the version string from "0x12345678" to "12345.67.8"
     #
     #>
     function formatMotionCodeVersionForUpgradeFile([ref]$AppVersionForUpgradeFile)
     {
        # remove '0x' from string
        $fmtTemp = $AppVersionForUpgradeFile.Value -replace '0x', ''
        if($fmtTemp.Length -eq 8)
        {
           $array = $fmtTemp.ToCharArray()
           # $array[0] = '{0:X4}'
           $stringVersionMainNumber = $array[0] + $array[1] + $array[2] + $array[3] + $array[4]
           $stringVersionSubNumber = $array[5] + $array[6]
           $stringVersionFixNumber = $array[7]
           $AppVersionForUpgradeFile.Value = $stringVersionMainNumber + '.' + $stringVersionSubNumber + '.' + $stringVersionFixNumber
        }
        else 
        {
            Write-Host ""
            Write-Host "##################################################"
            Write-Host "#       Version format invalid, use 'XXXX.YY.Z'  #"
            Write-Host "##################################################"
            Write-Host ""
            Start-Sleep 5
            $AppVersionForUpgradeFile.Value = "0000.00.0"
        }
    }

    <#
     # formatMotionCodeVariantForUpgradeFile()
     #
     # This function formats the variant string from "0x12345678" to "12.345678"
     #
     #>
    function formatMotionCodeVariantForUpgradeFile([ref]$AppVariantForUpgradeFile)
    {
        # remove '0x' from string
        $fmtTemp = $AppVariantForUpgradeFile.Value -replace '0x', ''
        if($fmtTemp.Length -eq 8)
        {
           $array = $fmtTemp.ToCharArray()
           $stringVersionMainNumber = $array[0] + $array[1]
           $stringVersionSubNumber = $array[2] + $array[3] + $array[4] + $array[5] + $array[6] + $array[7] + $array[8]
           $AppVariantForUpgradeFile.Value = $stringVersionMainNumber + '.' + $stringVersionSubNumber
        }
        else 
        {
            Write-Host ""
            Write-Host "##################################################"
            Write-Host "#     Variant format invalid, use 'XX.YYYYYY'    #"
            Write-Host "##################################################"
            Write-Host ""
            Start-Sleep 5
            $AppVariantForUpgradeFile.Value = "000000.00"
        }
    }

    ################################################################################
    ### Main Application starts here:                                            ###
    ################################################################################
    
    
    $toolchain = Join-Path $parEclipseHome "dunkermotoren/"
    $projPath = Join-Path $parProjDirPath $parConfigName
    $gcctoolchainPath = Join-Path $parEclipseHome "gcc-arm-none-eabi-10.3-2021.10/bin"
    $projName = $parProjName
    $libVersion = $parMotionCodeLibraryVersion
    $libVariant = $parMotionCodeLibraryVariant
    $materialNumber = $parMotionCodeMaterialNumber
    $materialIndex = $parMotionCodeMaterialIndex
    $FILENAME_EDIT_MAT_NUM_INDEX = "inhouse"
    $binFileName = "MotionCode.bin"
    $binFileComplete = Join-Path $projPath ($binFileName) # this file name should not be changed, because the DownloadFileSettings.xml expect it.
    
    $Upgrader = Get-Process Upgrader -ErrorAction SilentlyContinue
    if($Upgrader)
    { 
        Write-Host ""
        Write-Host "##################################################"
        Write-Host "#   Error, please close MCPUpgrader application! #"
        Write-Host "##################################################"
        Write-Host ""
        Start-Sleep 5
           
        exit 1        
    }
    

    if (Test-Path $toolchain$FILENAME_EDIT_MAT_NUM_INDEX -PathType Leaf) 
    { 
        Write-Host " ($toolchain$FILENAME_EDIT_MAT_NUM_INDEX) set new materialnumber and -index ..." 
    }
    else 
    { 
        #set default values 
        $materialNumber = "99999"
        $materialIndex = "0"
    }
    
    prepareToolchain $toolchain
    $generateXMLUpgrade = 0
    # check motion code library version and execute the corresponding function to prepare binary file
    if( ($libVersion -eq "0000B.00.0") -or ($libVersion -eq "00011.00.0") )
    {
        prepareBinFile $toolchain $projPath $projName $libVersion $libVariant $binFileComplete
    }
    else 
    {   
        prepareBinFile1 $toolchain $projPath $projName $libVersion $libVariant $binFileComplete $parMotionCodeVersion $parMotionCodeVariant $parMotionCodeVariantName
        $generateXMLUpgrade = 1
    }

    #Prepare materialnumber for downloadfile: If materialnumber has a dot(s) replace it with a blank:
    $materialNumberForDownloadFile = $materialNumber -replace '\.', ''
    generateDownloadFile $toolchain $libVersion $libVariant $materialNumberForDownloadFile $materialIndex $binFileComplete

    if($generateXMLUpgrade -eq 1)
    {
      $binFileUpgrade = "MotionCodeUpgrade.bin"
      generateUpgradeXMLFile $toolchain $parMotionCodeVersion $parMotionCodeVariant $materialNumber $materialIndex $binFileUpgrade $projPath 

    }
   
    
    cleanUpToolchain $toolchain $projPath
    