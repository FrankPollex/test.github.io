/**
 *******************************************************************************
 * @cond		Project: MotionCodeLibrary @endcond
 *******************************************************************************
 * @file		MotionCodeOd.h
 * @brief		
 * @version		Spec: 
 *******************************************************************************
 * @details	
 *******************************************************************************
 * @copyright	&copy; 2017 Dunkermotoren GmbH D-79848 Bonndorf,
 *				all rights reserved.
 *******************************************************************************
 * <h2 class="groupheader">SVN revision information</h2>
 * $Author$
 * $Date$
 * $Revision$ <HR>
 *******************************************************************************
 */

#ifndef INC_MOTIONCODEOD_H_
#define INC_MOTIONCODEOD_H_

/*---------------- Includes --------------------------------------------------*/
#include <stdint.h>
#include <ComObjectIF.h>

/*---------------- Public defines --------------------------------------------*/


/*---------------- Public typedefs -------------------------------------------*/

/*---------------- Public enums ----------------------------------------------*/

/*---------------- Public macros ---------------------------------------------*/

/*---------------- Public structs --------------------------------------------*/

/*---------------- Public module variable & constants declarations -----------*/
extern void *motionCode_parameterI32_01;
extern void *motionCode_parameterI32_02;
extern void *motionCode_parameterI32_03;
extern void *motionCode_parameterI32_04;
extern void *motionCode_parameterI32_05;
extern void *motionCode_parameterI32_06;
extern void *motionCode_parameterI32_07;
extern void *motionCode_parameterI32_08;
extern void *motionCode_parameterI32_09;
extern void *motionCode_parameterI32_10;
extern void *motionCode_parameterI32_11;
extern void *motionCode_parameterI32_12;
extern void *motionCode_parameterI32_13;
extern void *motionCode_parameterI32_14;
extern void *motionCode_parameterI32_15;
extern void *motionCode_parameterI32_16;
extern void *motionCode_parameterI32_17;
extern void *motionCode_parameterI32_18;
extern void *motionCode_parameterI32_19;
extern void *motionCode_parameterI32_20;
extern void *motionCode_parameterI32_21;
extern void *motionCode_parameterI32_22;
extern void *motionCode_parameterI32_23;
extern void *motionCode_parameterI32_24;
extern void *motionCode_parameterI32_25;
extern void *motionCode_parameterI32_26;
extern void *motionCode_parameterI32_27;
extern void *motionCode_parameterI32_28;
extern void *motionCode_parameterI32_29;
extern void *motionCode_parameterI32_30;
extern void *motionCode_parameterI32_31;
extern void *motionCode_parameterI32_32;
extern void *motionCode_parameterI32_33;
extern void *motionCode_parameterI32_34;
extern void *motionCode_parameterI32_35;
extern void *motionCode_parameterI32_36;
extern void *motionCode_parameterI32_37;
extern void *motionCode_parameterI32_38;
extern void *motionCode_parameterI32_39;
extern void *motionCode_parameterI32_40;
extern void *motionCode_parameterI32_41;
extern void *motionCode_parameterI32_42;
extern void *motionCode_parameterI32_43;
extern void *motionCode_parameterI32_44;
extern void *motionCode_parameterI32_45;
extern void *motionCode_parameterI32_46;
extern void *motionCode_parameterI32_47;
extern void *motionCode_parameterI32_48;
extern void *motionCode_parameterI32_49;
extern void *motionCode_parameterI32_50;

extern void *motionCode_parameterI32_01;
extern void *motionCode_parameterI32_02;
extern void *motionCode_parameterI32_03;
extern void *motionCode_parameterI32_04;
extern void *motionCode_parameterI32_05;
extern void *motionCode_parameterI32_06;
extern void *motionCode_parameterI32_07;
extern void *motionCode_parameterI32_08;
extern void *motionCode_parameterI32_09;
extern void *motionCode_parameterI32_10;
extern void *motionCode_parameterI32_11;
extern void *motionCode_parameterI32_12;
extern void *motionCode_parameterI32_13;
extern void *motionCode_parameterI32_14;
extern void *motionCode_parameterI32_15;
extern void *motionCode_parameterI32_16;
extern void *motionCode_parameterI32_17;
extern void *motionCode_parameterI32_18;
extern void *motionCode_parameterI32_19;
extern void *motionCode_parameterI32_20;
extern void *motionCode_parameterI32_21;
extern void *motionCode_parameterI32_22;
extern void *motionCode_parameterI32_23;
extern void *motionCode_parameterI32_24;
extern void *motionCode_parameterI32_25;
extern void *motionCode_parameterI32_26;
extern void *motionCode_parameterI32_27;
extern void *motionCode_parameterI32_28;
extern void *motionCode_parameterI32_29;
extern void *motionCode_parameterI32_30;
extern void *motionCode_parameterI32_31;
extern void *motionCode_parameterI32_32;
extern void *motionCode_parameterI32_33;
extern void *motionCode_parameterI32_34;
extern void *motionCode_parameterI32_35;
extern void *motionCode_parameterI32_36;
extern void *motionCode_parameterI32_37;
extern void *motionCode_parameterI32_38;
extern void *motionCode_parameterI32_39;
extern void *motionCode_parameterI32_40;
extern void *motionCode_parameterI32_41;
extern void *motionCode_parameterI32_42;
extern void *motionCode_parameterI32_43;
extern void *motionCode_parameterI32_44;
extern void *motionCode_parameterI32_45;
extern void *motionCode_parameterI32_46;
extern void *motionCode_parameterI32_47;
extern void *motionCode_parameterI32_48;
extern void *motionCode_parameterI32_49;
extern void *motionCode_parameterI32_50;

extern void *motionCode_parameterUI32_01;
extern void *motionCode_parameterUI32_02;
extern void *motionCode_parameterUI32_03;
extern void *motionCode_parameterUI32_04;
extern void *motionCode_parameterUI32_05;
extern void *motionCode_parameterUI32_06;
extern void *motionCode_parameterUI32_07;
extern void *motionCode_parameterUI32_08;
extern void *motionCode_parameterUI32_09;
extern void *motionCode_parameterUI32_10;
extern void *motionCode_parameterUI32_11;
extern void *motionCode_parameterUI32_12;
extern void *motionCode_parameterUI32_13;
extern void *motionCode_parameterUI32_14;
extern void *motionCode_parameterUI32_15;
extern void *motionCode_parameterUI32_16;
extern void *motionCode_parameterUI32_17;
extern void *motionCode_parameterUI32_18;
extern void *motionCode_parameterUI32_19;
extern void *motionCode_parameterUI32_20;
extern void *motionCode_parameterUI32_21;
extern void *motionCode_parameterUI32_22;
extern void *motionCode_parameterUI32_23;
extern void *motionCode_parameterUI32_24;
extern void *motionCode_parameterUI32_25;
extern void *motionCode_parameterUI32_26;
extern void *motionCode_parameterUI32_27;
extern void *motionCode_parameterUI32_28;
extern void *motionCode_parameterUI32_29;
extern void *motionCode_parameterUI32_30;
extern void *motionCode_parameterUI32_31;
extern void *motionCode_parameterUI32_32;
extern void *motionCode_parameterUI32_33;
extern void *motionCode_parameterUI32_34;
extern void *motionCode_parameterUI32_35;
extern void *motionCode_parameterUI32_36;
extern void *motionCode_parameterUI32_37;
extern void *motionCode_parameterUI32_38;
extern void *motionCode_parameterUI32_39;
extern void *motionCode_parameterUI32_40;
extern void *motionCode_parameterUI32_41;
extern void *motionCode_parameterUI32_42;
extern void *motionCode_parameterUI32_43;
extern void *motionCode_parameterUI32_44;
extern void *motionCode_parameterUI32_45;
extern void *motionCode_parameterUI32_46;
extern void *motionCode_parameterUI32_47;
extern void *motionCode_parameterUI32_48;
extern void *motionCode_parameterUI32_49;
extern void *motionCode_parameterUI32_50;

extern void *motionCode_parameterI16_01;
extern void *motionCode_parameterI16_02;
extern void *motionCode_parameterI16_03;
extern void *motionCode_parameterI16_04;
extern void *motionCode_parameterI16_05;
extern void *motionCode_parameterI16_06;
extern void *motionCode_parameterI16_07;
extern void *motionCode_parameterI16_08;
extern void *motionCode_parameterI16_09;
extern void *motionCode_parameterI16_10;
extern void *motionCode_parameterI16_11;
extern void *motionCode_parameterI16_12;
extern void *motionCode_parameterI16_13;
extern void *motionCode_parameterI16_14;
extern void *motionCode_parameterI16_15;
extern void *motionCode_parameterI16_16;
extern void *motionCode_parameterI16_17;
extern void *motionCode_parameterI16_18;
extern void *motionCode_parameterI16_19;
extern void *motionCode_parameterI16_20;
extern void *motionCode_parameterI16_21;
extern void *motionCode_parameterI16_22;
extern void *motionCode_parameterI16_23;
extern void *motionCode_parameterI16_24;
extern void *motionCode_parameterI16_25;
extern void *motionCode_parameterI16_26;
extern void *motionCode_parameterI16_27;
extern void *motionCode_parameterI16_28;
extern void *motionCode_parameterI16_29;
extern void *motionCode_parameterI16_30;
extern void *motionCode_parameterI16_31;
extern void *motionCode_parameterI16_32;
extern void *motionCode_parameterI16_33;
extern void *motionCode_parameterI16_34;
extern void *motionCode_parameterI16_35;
extern void *motionCode_parameterI16_36;
extern void *motionCode_parameterI16_37;
extern void *motionCode_parameterI16_38;
extern void *motionCode_parameterI16_39;
extern void *motionCode_parameterI16_40;
extern void *motionCode_parameterI16_41;
extern void *motionCode_parameterI16_42;
extern void *motionCode_parameterI16_43;
extern void *motionCode_parameterI16_44;
extern void *motionCode_parameterI16_45;
extern void *motionCode_parameterI16_46;
extern void *motionCode_parameterI16_47;
extern void *motionCode_parameterI16_48;
extern void *motionCode_parameterI16_49;
extern void *motionCode_parameterI16_50;

extern void *motionCode_parameterUI16_01;
extern void *motionCode_parameterUI16_02;
extern void *motionCode_parameterUI16_03;
extern void *motionCode_parameterUI16_04;
extern void *motionCode_parameterUI16_05;
extern void *motionCode_parameterUI16_06;
extern void *motionCode_parameterUI16_07;
extern void *motionCode_parameterUI16_08;
extern void *motionCode_parameterUI16_09;
extern void *motionCode_parameterUI16_10;
extern void *motionCode_parameterUI16_11;
extern void *motionCode_parameterUI16_12;
extern void *motionCode_parameterUI16_13;
extern void *motionCode_parameterUI16_14;
extern void *motionCode_parameterUI16_15;
extern void *motionCode_parameterUI16_16;
extern void *motionCode_parameterUI16_17;
extern void *motionCode_parameterUI16_18;
extern void *motionCode_parameterUI16_19;
extern void *motionCode_parameterUI16_20;
extern void *motionCode_parameterUI16_21;
extern void *motionCode_parameterUI16_22;
extern void *motionCode_parameterUI16_23;
extern void *motionCode_parameterUI16_24;
extern void *motionCode_parameterUI16_25;
extern void *motionCode_parameterUI16_26;
extern void *motionCode_parameterUI16_27;
extern void *motionCode_parameterUI16_28;
extern void *motionCode_parameterUI16_29;
extern void *motionCode_parameterUI16_39;
extern void *motionCode_parameterUI16_30;
extern void *motionCode_parameterUI16_31;
extern void *motionCode_parameterUI16_32;
extern void *motionCode_parameterUI16_33;
extern void *motionCode_parameterUI16_34;
extern void *motionCode_parameterUI16_35;
extern void *motionCode_parameterUI16_36;
extern void *motionCode_parameterUI16_37;
extern void *motionCode_parameterUI16_38;
extern void *motionCode_parameterUI16_39;
extern void *motionCode_parameterUI16_40;
extern void *motionCode_parameterUI16_41;
extern void *motionCode_parameterUI16_42;
extern void *motionCode_parameterUI16_43;
extern void *motionCode_parameterUI16_44;
extern void *motionCode_parameterUI16_45;
extern void *motionCode_parameterUI16_46;
extern void *motionCode_parameterUI16_47;
extern void *motionCode_parameterUI16_48;
extern void *motionCode_parameterUI16_49;
extern void *motionCode_parameterUI16_50;

extern void *motionCode_parameterI8_01;
extern void *motionCode_parameterI8_02;
extern void *motionCode_parameterI8_03;
extern void *motionCode_parameterI8_04;
extern void *motionCode_parameterI8_05;
extern void *motionCode_parameterI8_06;
extern void *motionCode_parameterI8_07;
extern void *motionCode_parameterI8_08;
extern void *motionCode_parameterI8_09;
extern void *motionCode_parameterI8_10;
extern void *motionCode_parameterI8_11;
extern void *motionCode_parameterI8_12;
extern void *motionCode_parameterI8_13;
extern void *motionCode_parameterI8_14;
extern void *motionCode_parameterI8_15;
extern void *motionCode_parameterI8_16;
extern void *motionCode_parameterI8_17;
extern void *motionCode_parameterI8_18;
extern void *motionCode_parameterI8_19;
extern void *motionCode_parameterI8_20;
extern void *motionCode_parameterI8_21;
extern void *motionCode_parameterI8_22;
extern void *motionCode_parameterI8_23;
extern void *motionCode_parameterI8_24;
extern void *motionCode_parameterI8_25;
extern void *motionCode_parameterI8_26;
extern void *motionCode_parameterI8_27;
extern void *motionCode_parameterI8_28;
extern void *motionCode_parameterI8_29;
extern void *motionCode_parameterI8_30;
extern void *motionCode_parameterI8_31;
extern void *motionCode_parameterI8_32;
extern void *motionCode_parameterI8_33;
extern void *motionCode_parameterI8_34;
extern void *motionCode_parameterI8_35;
extern void *motionCode_parameterI8_36;
extern void *motionCode_parameterI8_37;
extern void *motionCode_parameterI8_38;
extern void *motionCode_parameterI8_39;
extern void *motionCode_parameterI8_40;
extern void *motionCode_parameterI8_41;
extern void *motionCode_parameterI8_42;
extern void *motionCode_parameterI8_43;
extern void *motionCode_parameterI8_44;
extern void *motionCode_parameterI8_45;
extern void *motionCode_parameterI8_46;
extern void *motionCode_parameterI8_47;
extern void *motionCode_parameterI8_48;
extern void *motionCode_parameterI8_49;
extern void *motionCode_parameterI8_50;

extern void *motionCode_parameterUI8_01;
extern void *motionCode_parameterUI8_02;
extern void *motionCode_parameterUI8_03;
extern void *motionCode_parameterUI8_04;
extern void *motionCode_parameterUI8_05;
extern void *motionCode_parameterUI8_06;
extern void *motionCode_parameterUI8_07;
extern void *motionCode_parameterUI8_08;
extern void *motionCode_parameterUI8_09;
extern void *motionCode_parameterUI8_10;
extern void *motionCode_parameterUI8_11;
extern void *motionCode_parameterUI8_12;
extern void *motionCode_parameterUI8_13;
extern void *motionCode_parameterUI8_14;
extern void *motionCode_parameterUI8_15;
extern void *motionCode_parameterUI8_16;
extern void *motionCode_parameterUI8_17;
extern void *motionCode_parameterUI8_18;
extern void *motionCode_parameterUI8_19;
extern void *motionCode_parameterUI8_20;
extern void *motionCode_parameterUI8_21;
extern void *motionCode_parameterUI8_22;
extern void *motionCode_parameterUI8_23;
extern void *motionCode_parameterUI8_24;
extern void *motionCode_parameterUI8_25;
extern void *motionCode_parameterUI8_26;
extern void *motionCode_parameterUI8_27;
extern void *motionCode_parameterUI8_28;
extern void *motionCode_parameterUI8_29;
extern void *motionCode_parameterUI8_30;
extern void *motionCode_parameterUI8_31;
extern void *motionCode_parameterUI8_32;
extern void *motionCode_parameterUI8_33;
extern void *motionCode_parameterUI8_34;
extern void *motionCode_parameterUI8_35;
extern void *motionCode_parameterUI8_36;
extern void *motionCode_parameterUI8_37;
extern void *motionCode_parameterUI8_38;
extern void *motionCode_parameterUI8_39;
extern void *motionCode_parameterUI8_40;
extern void *motionCode_parameterUI8_41;
extern void *motionCode_parameterUI8_42;
extern void *motionCode_parameterUI8_43;
extern void *motionCode_parameterUI8_44;
extern void *motionCode_parameterUI8_45;
extern void *motionCode_parameterUI8_46;
extern void *motionCode_parameterUI8_47;
extern void *motionCode_parameterUI8_48;
extern void *motionCode_parameterUI8_49;
extern void *motionCode_parameterUI8_50;

/*---------------- Public module function declarations -----------------------*/
extern com_object_if_error_t motionCode_odGetParameter(void* const this, com_object_if_variable_t* value);
extern com_object_if_error_t motionCode_odSetParameter(void* const this, com_object_if_variable_t value);

#endif /* INC_MOTIONCODEOD_H_ */
