/**
 *******************************************************************************
 * @cond		Project: MotionCode @endcond
 *******************************************************************************
 * @file		MotionCodeNotificationType.h
 * @brief		
 * @version		Spec: 
 *******************************************************************************
 * @details	
 *******************************************************************************
 * @copyright	&copy; 2017 Dunkermotoren GmbH D-79848 Bonndorf,
 *				all rights reserved.
 *******************************************************************************
 * <h2 class="groupheader">SVN revision information</h2>
 * $Author: frank.pollex $
 * $Date: 2022-07-22 16:25:19 +0200 (Fr, 22 Jul 2022) $
 * $Revision: 507 $ <HR>
 *******************************************************************************
 */

#ifndef MOTIONCODENOTIFICATIONTYPE_H_
#define MOTIONCODENOTIFICATIONTYPE_H_

/*---------------- Includes --------------------------------------------------*/
#include <stdint.h>

/*---------------- Public defines --------------------------------------------*/

/*---------------- Public typedefs -------------------------------------------*/
typedef enum motion_code_notification_type motion_code_notification_type_t;

/*---------------- Public enums ----------------------------------------------*/
enum motion_code_notification_type
{
	UPDATED_MOTION_CODE
};

/*---------------- Public macros ---------------------------------------------*/

/*---------------- Public structs --------------------------------------------*/

/*---------------- Public module variable & constants declarations -----------*/

/*---------------- Public module function declarations -----------------------*/


#endif /* MOTIONCODENOTIFICATIONTYPE_H_ */
