/**
 *******************************************************************************
 * @cond		Project: DriveUnit @endcond
 *******************************************************************************
 * @file		ComObjectIF.h
 * @brief		Interface between Object Dictionary and SW Modules
 * @version		Spec: ObjectDictionary 2.2
 *******************************************************************************
 * @details	
 *******************************************************************************
 * @copyright	&copy; 2015 Dunkermotoren GmbH D-79848 Bonndorf,
 *				all rights reserved.
 *******************************************************************************
 * <h2 class="groupheader">SVN revision information</h2>
 * $Author: frank.pollex $
 * $Date: 2022-07-22 16:25:19 +0200 (Fr, 22 Jul 2022) $
 * $Revision: 507 $ <HR>
 *******************************************************************************
 */

#ifndef COMOBJECTIF_H_
#define COMOBJECTIF_H_

/*---------------- Includes --------------------------------------------------*/
#include <stdint.h>
#include <SpecificTypes.h>
/*---------------- Public defines --------------------------------------------*/

/*---------------- Public typedefs -------------------------------------------*/
typedef enum com_object_if_error com_object_if_error_t;
typedef union com_object_if_variable com_object_if_variable_t;

/* Setter ,getter and restore default value function callback */
typedef com_object_if_error_t (*com_object_if_set_func_t)(void* const this,com_object_if_variable_t data);
typedef com_object_if_error_t (*com_object_if_get_func_t)(void* const this,com_object_if_variable_t* data);
typedef com_object_if_error_t (*com_object_if_restore_default_func_t)(void* const this);


/*---------------- Public enums ----------------------------------------------*/
enum com_object_if_error
{
	ERROR_NONE,
	ERROR_VALUE_TOO_BIG,
	ERROR_VALUE_TOO_SMALL,
	ERROR_VALUE_NOT_SUPPORTED,
	ERROR_NOT_ALLOWED_IN_ACTUAL_STATE,
	ERROR_OUT_OF_RANGE,
	ERROR_OBJECT_NOT_EXIST,
	ERROR_GENERAL_ERROR,
	ERROR_USER_CALLBACK_TIMEOUT,
	ERROR_NO_READ_PERMISSION,
	ERROR_NO_WRITE_PERMISSION,
	ERROR_SUBIDX_0_MUST_BE_0_FOR_WRITE_ACCESS
};

/*---------------- Public macros ---------------------------------------------*/

/*---------------- Public structs --------------------------------------------*/
union com_object_if_variable
{
 	int8_t	i8;
 	uint8_t ui8;
 	int16_t	i16;
 	uint16_t ui16;
 	int32_t	i32;
 	uint32_t ui32;
 	float_t f32;
 	int64_t i64;
 	uint64_t ui64;
 	double_t f64;
 	uint8_t* string;
};

/*---------------- Public module variable & constants declarations -----------*/

/*---------------- Public module function declarations -----------------------*/

#endif /* COMOBJECTIF_H_ */
