/**
 *******************************************************************************
 * @cond		Project: MotionCodeLibrary @endcond
 *******************************************************************************
 * @file		DriveLib.h
 * @brief		The interface for the DriveLib module
 * @version		Spec: 1.4
 *******************************************************************************
 * @details		For detailed information on what the implementations do please
 * 				refer to the implementation header files.
 *******************************************************************************
 * @copyright	&copy; 2017 Dunkermotoren GmbH D-79848 Bonndorf,
 *				all rights reserved.
 *******************************************************************************
 * <h2 class="groupheader">SVN revision information</h2>
 * $Author: frank.pollex $
 * $Date: 2022-07-20 10:51:50 +0200 (Mi, 20 Jul 2022) $
 * $Revision: 501 $ <HR>
 *******************************************************************************
 */

#ifndef INC_DRIVELIBIF_H_
#define INC_DRIVELIBIF_H_

/*---------------- Includes --------------------------------------------------*/
#include <stdint.h>
#include <DriveParameters.h>
#include <ComObjectIF.h>
/*---------------- Public defines --------------------------------------------*/

/*---------------- Public typedefs -------------------------------------------*/

typedef enum drive_lib_if_error drive_lib_if_error_t;
typedef struct drive_lib_if drive_lib_if_t;
typedef struct drive_lib_if_config drive_lib_if_config_t;
typedef union drive_lib_if_memory drive_lib_if_memory_t;

/*---------------- Public enums ----------------------------------------------*/
enum drive_lib_if_error {
	DRIVE_NO_ERROR,
	DRIVE_VALUE_TOO_BIG,
	DRIVE_VALUE_TOO_SMALL,
	DRIVE_VALUE_NOT_SUPPORTED,
	DRIVE_NOT_ALLOWED_IN_ACTUAL_STATE,
	DRIVE_OUT_OF_RANGE,
	DRIVE_OBJECT_NOT_EXIST,
	DRIVE_GENERAL_ERROR,
	DRIVE_USER_CALLBACK_TIMEOUT,
	DRIVE_NO_READ_PERMISSION,
	DRIVE_NO_WRITE_PERMISSION
};

/*---------------- Public macros ---------------------------------------------*/

/*---------------- Public structs --------------------------------------------*/

struct drive_lib_if
{
	drive_lib_if_memory_t** memory;

	drive_lib_if_error_t (*writeUi8) (drive_parameters_t parameter, uint8_t srcValue);
	drive_lib_if_error_t (*writeI8) (drive_parameters_t parameter, int8_t srcValue);
	drive_lib_if_error_t (*writeUi16) (drive_parameters_t parameter, uint16_t srcValue);
	drive_lib_if_error_t (*writeI16) (drive_parameters_t parameter, int16_t srcValue);
	drive_lib_if_error_t (*writeUi32) (drive_parameters_t parameter, uint32_t srcValue);
	drive_lib_if_error_t (*writeI32) (drive_parameters_t parameter, int32_t srcValue);
	drive_lib_if_error_t (*writeUi64) (drive_parameters_t parameter, uint64_t srcValue);
	drive_lib_if_error_t (*writeI64) (drive_parameters_t parameter, int64_t srcValue);
	drive_lib_if_error_t (*writeFloat) (drive_parameters_t parameter, float_t srcValue);
	drive_lib_if_error_t (*writeDouble) (drive_parameters_t parameter, double_t srcValue);
	drive_lib_if_error_t (*writeString) (drive_parameters_t parameter, uint8_t* srcValue);

	drive_lib_if_error_t (*readUi8) (drive_parameters_t parameter, uint8_t *destValue);
	drive_lib_if_error_t (*readI8) (drive_parameters_t parameter, int8_t *destValue);
	drive_lib_if_error_t (*readUi16) (drive_parameters_t parameter, uint16_t *destValue);
	drive_lib_if_error_t (*readI16) (drive_parameters_t parameter, int16_t *destValue);
	drive_lib_if_error_t (*readUi32) (drive_parameters_t parameter, uint32_t *destValue);
	drive_lib_if_error_t (*readI32) (drive_parameters_t parameter, int32_t *destValue);
	drive_lib_if_error_t (*readUi64) (drive_parameters_t parameter, uint64_t *destValue);
	drive_lib_if_error_t (*readI64) (drive_parameters_t parameter, int64_t *destValue);
	drive_lib_if_error_t (*readFloat) (drive_parameters_t parameter, float_t *destValue);
	drive_lib_if_error_t (*readDouble) (drive_parameters_t parameter, double_t *destValue);
	drive_lib_if_error_t (*readString) (drive_parameters_t parameter, uint8_t* destValue);

	bool_t	(*store) (uint32_t mask);
	bool_t	(*restore) (uint32_t mask);

	bool_t	(*storeExtended) (uint32_t mask3,uint32_t mask2, uint32_t mask1, uint32_t mask0);
	bool_t	(*restoreExtended) (uint32_t mask3,uint32_t mask2, uint32_t mask1, uint32_t mask0);
};


struct drive_lib_if_config {
	uint32_t	(*write) (uint32_t key, com_object_if_variable_t* scrValue );
	uint32_t	(*read) (uint32_t key, com_object_if_variable_t* destValue );
};

union drive_lib_if_memory {
	int8_t i8;
	uint8_t ui8;
	int16_t i16;
	uint16_t ui16;
	int32_t i32;
	uint32_t ui32;
	float_t f32;
};

/*---------------- Public module variable & constants declarations -----------*/

/*---------------- Public module function declarations -----------------------*/


#endif /* INC_DRIVELIBIF_H_ */

