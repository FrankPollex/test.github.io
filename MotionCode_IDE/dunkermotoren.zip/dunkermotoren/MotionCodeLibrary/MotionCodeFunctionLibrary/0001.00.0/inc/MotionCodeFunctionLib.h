/**
 ********************************************************************************
 * MotionCodeFunctionLib-Version:   001.00
 * MotionCodeLibrary:               Minimum 0001E.00.0
 ********************************************************************************
 * Description:
 * In this module are some useful things predefined.
 * Please be aware of the MotionCode software documentation.
 * --> DO NOT CHANGE OR REMOVE
********************************************************************************
 */

#ifndef INC_MOTIONCODEFUNCTIONLIB_H_
#define INC_MOTIONCODEFUNCTIONLIB_H_

/**---------------- Includes --------------------------------------------------*/
#include <stdint.h>                                                             // Include fixed width integer types
#include <stdbool.h>                                                            // Include datatype bool

/**---------------- Public defines --------------------------------------------*/

/**---------------- Public typedefs -------------------------------------------*/

/**---------------- Public enums ----------------------------------------------*/
/*
 *******************************************************************************
 * Description:
 * Assign names to bits of DEVICE_StatusRegister
 *******************************************************************************
*/
enum motionCodeFunctionLib_tags_for_DEVICE_StatusRegister
{
    STAT_Enabled            = 0x00000001,                                       // Bit  0
    STAT_Error              = 0x00000002,                                       // Bit  1
    STAT_Warning            = 0x00000004,                                       // Bit  2
    STAT_Moving             = 0x00000008,                                       // Bit  3
    STAT_Reached            = 0x00000010,                                       // Bit  4
    STAT_Limit              = 0x00000020,                                       // Bit  5
    STAT_FollowingError     = 0x00000040,                                       // Bit  6
    STAT_HomingDone         = 0x00000080,                                       // Bit  7
    STAT_Toggle             = 0x00000100,                                       // Bit  8
    STAT_CommandToggle      = 0x00000200,                                       // Bit  9
    STAT_CommandError       = 0x00000400,                                       // Bit 10
    STAT_StopOrHalt         = 0x00000800,                                       // Bit 11
    STAT_LimitCurrent       = 0x00001000,                                       // Bit 12
    STAT_LimitVel           = 0x00002000,                                       // Bit 13
    STAT_LimitPos           = 0x00004000,                                       // Bit 14
    STAT_LimitPWM           = 0x00008000,                                       // Bit 15
    STAT_LimitSetpointVq    = 0x00010000,                                       // Bit 16
    STAT_LimitSetpointVd    = 0x00020000,                                       // Bit 17
    STAT_ComOperational     = 0x00040000,                                       // Bit 18
    STAT_ComStarted         = 0x00080000,                                       // Bit 19
    STAT_OverTemperature    = 0x00100000,                                       // Bit 20
    STAT_MotorOvervoltage   = 0x00200000,                                       // Bit 21
    STAT_MotorUndervoltage  = 0x00400000,                                       // Bit 22
    STAT_Blockage           = 0x00800000,                                       // Bit 23
    STAT_ParamCmdExec       = 0x01000000,                                       // Bit 24
    STAT_BallastCircuit     = 0x02000000,                                       // Bit 25
    STAT_Direction          = 0x04000000,                                       // Bit 26
    STAT_Overload           = 0x08000000,                                       // Bit 27
    STAT_PS_HW_ENABLED      = 0x10000000,                                       // Bit 28
};

/**---------------- Public macros ---------------------------------------------*/

/**---------------- Public structs --------------------------------------------*/

/**---------------- Public module variable & constants declarations -----------*/

/**---------------- Public module function declarations -----------------------*/
/*
 *******************************************************************************
 * Description:
 * Returns debounced value of digital inputs. With digitalInputMask the
 * necessary inputs are selected. The debounce Time is defined by debounceTime.
 * Always use the same digitalInputMask. If you need several inputs debounced
 * separately copy the function for each instance into ProgramSpecificFunctions.
 * ATTENTION! You have to call the function cyclic, otherwise it will not work!
 * --> DO NOT CHANGE OR REMOVE
 *******************************************************************************
 * Input values:
 * uint8_t digitalInputMask --> Choose the relevant inputs.
 * uint32_t debounceTime --> Set debounce time [ms]
 *******************************************************************************
 * Return values:
 * uint8_t digitalInputsLastValidValue --> debounced & masked digital inputs
 *******************************************************************************
*/
extern uint8_t motionCodeFunctionLib_readDebouncedDigitalInputs(uint8_t digitalInputMask, uint32_t debounceTime);

/*
 *******************************************************************************
 * Description:
 * Returns "true" if timeDelay is elapsed since startTime.
 * ATTANTION: Only time difference <= 10 minutes (600'000'000�s) possible!!!
 * --> DO NOT CHANGE OR REMOVE
 *******************************************************************************
 * Input values:
 * uint32_t startTime --> Value of DEVICE_Timer which is compared to [�s]
 * uint32_t timeDelay --> Time delay which is added to startTime [�s]
 *******************************************************************************
 * Return values:
 * bool 'true or false' --> True if time is elapsed, false if not.
 *******************************************************************************
*/
extern bool motionCodeFunctionLib_timerTrueAfterDelay(uint32_t startTime, uint32_t timeDelay);

/*
 *******************************************************************************
 * Description:
 * Returns "true" in the first half of periodTime and "false" in the second. To
 * ensure, that the first pulse is complete, the startTime must be provided.
 * --> If this is not important a given 0 is ok
 * --> DO NOT CHANGE OR REMOVE
 *******************************************************************************
 * Input values:
 * uint32_t startTime --> Value of DEVICE_Timer which is compared to [�s]
 * uint32_t periodTime --> Period time of generated pulses [�s]
 *******************************************************************************
 * Return values:
 * bool 'true or false' --> Toggles with given period time if called cyclic.
 *******************************************************************************
*/
extern bool motionCodeFunctionLib_pulseTimer(uint32_t startTime, uint32_t periodTime);

/*
 *******************************************************************************
 * Description:
 * Check positive edge at motionParameterStoreCmd to store all motionParameters.
 * The motionParameter int32_t "motionParameterStoreCmd" is mandatory!!!
 * --> DO NOT CHANGE OR REMOVE
 *******************************************************************************
*/
void motionCodeFunctionLib_checkMotionParameterStoreCmd(void);

#endif /* INC_MOTIONCODEFUNCTIONLIB_H_ */
