/**
 *******************************************************************************
 * @cond        Project: MotionCodeLibrary @endcond
 *******************************************************************************
 * @file        DriveLib.h
 * @brief       Common module for the DriveLib
 * @version     Spec: 1.4
 *******************************************************************************
 * @details     This module selects the active implementation from the sub
 *              implementations.
 *******************************************************************************
 * @copyright   &copy; 2017 Dunkermotoren GmbH D-79848 Bonndorf,
 *              all rights reserved.
 *******************************************************************************
 * <h2 class="groupheader">SVN revision information</h2>
 * $Author: frank.pollex $
 * $Date: 2021-10-29 15:10:16 +0200 (Fr, 29 Okt 2021) $
 * $Revision: 22327 $ <HR>
 *******************************************************************************
 */

#ifndef INC_DRIVELIB_H_
#define INC_DRIVELIB_H_

/*---------------- Includes --------------------------------------------------*/
#include <stdint.h>
#include <SpecificTypes.h>
#include <DriveLibIF.h>

/*---------------- Public defines --------------------------------------------*/

/*---------------- Public typedefs -------------------------------------------*/

/*---------------- Public enums ----------------------------------------------*/

/*---------------- Public macros ---------------------------------------------*/

/*---------------- Public structs --------------------------------------------*/

/*---------------- Public module variable & constants declarations -----------*/
// Axivion disable style Generic-NamingConvention
// Axivion disable style MisraC2012-8.9
// Disable axivion because the interface concept requires this naming convention
extern const drive_lib_if_t* drive;
// Axivion enable style MisraC2012-8.9
// Axivion enable style Generic-NamingConvention
/*---------------- Public module function declarations -----------------------*/

/*---------------- Public module function declarations -----------------------*/

/**
 *******************************************************************************
 * @brief        Initialisation function
 * @param[in]    selectedDriveLib - a pointer to a structure which holds the
 *               selected DriveLib implementation's read and write functionpointers
 *
 * @retval       bool_t: true - Drivelib initialized
 *                       false - DriveLib was not initialized
 *******************************************************************************
 * @details      The init function sets the drive pointer to the selectedDriveLib
 *               structure.
 *******************************************************************************
*/
extern bool_t driveLib_init(const drive_lib_if_t* const selectedDriveLib);

#endif /* INC_DRIVELIB_H_ */
