/**
 *******************************************************************************
 * @cond		Project: DriveUnit @endcond
 *******************************************************************************
 * @file		SpecificTypes.h
 * @brief		Specific Types for the whole Motor Control Project
 * @version		Spec: None
 *******************************************************************************
 * @details	    Specific types for common use by several modules and typedefs
 *              to be confirm with MISRA.
 *******************************************************************************
 * @copyright	&copy; 2015 Dunkermotoren GmbH D-79848 Bonndorf,
 *				all rights reserved.
 *******************************************************************************
 * <h2 class="groupheader">SVN revision information</h2>
 * $Author: frank.pollex $
 * $Date: 2023-03-09 15:42:02 +0100 (Do, 09 Mrz 2023) $
 * $Revision: 526 $ <HR>
 *******************************************************************************
 */

#ifndef SPECIFICTYPES_H
#define SPECIFICTYPES_H

/* ------------- Includes --------------------------------------------------- */
#include <stdbool.h>
#include <math.h>
#include <stdint.h>

/* ------------- Public defines --------------------------------------------- */

/* ----------------- BOOLEAN DEFINES ------------------ */

// Note: The following defines shall not be used in upcoming code. The aim is,
//		 to get rid of them someday!
#define  FALSE                                         0U
#define  TRUE                                          1U

#define  OFF                                           0U
#define  ON                                            1U

/* ------------- Public enums ----------------------------------------------- */

/* ------------- Public macros ---------------------------------------------- */

/* ------------- Public typedefs -------------------------------------------- */
typedef bool bool_t;
typedef uint8_t char_t;

/* ------------- Public module variable Declarations ------------------------ */


/* ------------- Public module function Declarations ------------------------ */

#endif /* SPECIFICTYPES_H */
