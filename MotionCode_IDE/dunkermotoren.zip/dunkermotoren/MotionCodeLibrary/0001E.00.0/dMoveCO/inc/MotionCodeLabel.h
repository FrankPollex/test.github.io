/**
 *******************************************************************************
 * @cond		Project: MotionCodeLibrary @endcond
 *******************************************************************************
 * @file		MotionCodeLabel.h
 * @brief       The SW module MotionCodeLabel read out predefined application
 *              parameter
 * @version		Spec: 1.0
 *******************************************************************************
 * @details	
 *******************************************************************************
 * @copyright	&copy; 2019 Dunkermotoren GmbH D-79848 Bonndorf,
 *				all rights reserved.
 *******************************************************************************
 * <h2 class="groupheader">SVN revision information</h2>
 * $Author: frank.pollex $
 * $Date: 2022-07-20 10:51:50 +0200 (Mi, 20 Jul 2022) $
 * $Revision: 501 $ <HR>
 *******************************************************************************
 */

#ifndef INC_PARAMETER_MOTIONCODELABEL_H_
#define INC_PARAMETER_MOTIONCODELABEL_H_

/*---------------- Includes --------------------------------------------------*/
#include <stdint.h>
#include <ComObjectIF.h>

/*---------------- Public defines --------------------------------------------*/
#define c_MAXIMAL_STRING_LENGTH 64u /**< Maximum string length (include EOS) */

/*---------------- Public typedefs -------------------------------------------*/

/*---------------- Public enums ----------------------------------------------*/

/*---------------- Public macros ---------------------------------------------*/

/*---------------- Public structs --------------------------------------------*/

/*---------------- Public module variable & constants declarations -----------*/

/*---------------- Public module function declarations -----------------------*/



/**
 *******************************************************************************
 * @brief Read motion app variant number
 * @param [in]  this - not used
 * @param [out] variantNumber: uint32_t
 * @retval ERROR_NONE
 *******************************************************************************
 * @details
 *******************************************************************************
*/
extern com_object_if_error_t motionCodeLabel_odGetVariantNumber(void* const this, com_object_if_variable_t* variantNumber);

/**
 *******************************************************************************
 * @brief Read motion app variant name
 * @param [in]  this - not used
 * @param [out] variantName - null terminated string with max. MOTION_CODE_MAXIMAL_STRING_LENGTH
 * @retval ERROR_NONE
 *******************************************************************************
 * @details
 *******************************************************************************
*/
com_object_if_error_t motionCodeLabel_odGetVariantName(void* const this, com_object_if_variable_t* variantName);

/**
 *******************************************************************************
 * @brief Read motion app version
 * @param [in]  this - not used
 * @param [out] version: uint32_t
 * @retval ERROR_NONE
 *******************************************************************************
 * @details
 *******************************************************************************
*/
com_object_if_error_t  motionCodeLabel_odGetVersion(void* const this, com_object_if_variable_t* version);


#endif /* INC_PARAMETER_MOTIONCODELABEL_H_ */
