/**
 *******************************************************************************
 * @cond		Project: MotionCodeLibrary @endcond
 *******************************************************************************
 * @file		MotionParameterNames.h
 * @brief		
 * @version		Spec: 
 *******************************************************************************
 * @details	
 *******************************************************************************
 * @copyright	&copy; 2017 Dunkermotoren GmbH D-79848 Bonndorf,
 *				all rights reserved.
 *******************************************************************************
 * <h2 class="groupheader">SVN revision information</h2>
 * $Author: frank.pollex $
 * $Date: 2022-07-20 10:51:50 +0200 (Mi, 20 Jul 2022) $
 * $Revision: 501 $ <HR>
 *******************************************************************************
 */

#ifndef INC_MOTIONPARAMETERNAMES_H_
#define INC_MOTIONPARAMETERNAMES_H_

/*---------------- Includes --------------------------------------------------*/
#include <stdint.h>

/*---------------- Public defines --------------------------------------------*/
#define PARAMETER *(motion_parameter_names_t*)this

/*---------------- Public typedefs -------------------------------------------*/
typedef enum motion_parameter_names motion_parameter_names_t;

/*---------------- Public enums ----------------------------------------------*/
enum motion_parameter_names
{
		MOTIONCODE_PARAMETER_I32_01 = 1u,
		MOTIONCODE_PARAMETER_I32_02 = 2u,
		MOTIONCODE_PARAMETER_I32_03 = 3u,
		MOTIONCODE_PARAMETER_I32_04 = 4u,
		MOTIONCODE_PARAMETER_I32_05 = 5u,
		MOTIONCODE_PARAMETER_I32_06 = 6u,
		MOTIONCODE_PARAMETER_I32_07 = 7u,
		MOTIONCODE_PARAMETER_I32_08 = 8u,
		MOTIONCODE_PARAMETER_I32_09 = 9u,
		MOTIONCODE_PARAMETER_I32_10 = 10u,
		MOTIONCODE_PARAMETER_I32_11 = 11u,
		MOTIONCODE_PARAMETER_I32_12 = 12u,
		MOTIONCODE_PARAMETER_I32_13 = 13u,
		MOTIONCODE_PARAMETER_I32_14 = 14u,
		MOTIONCODE_PARAMETER_I32_15 = 15u,
		MOTIONCODE_PARAMETER_I32_16 = 16u,
		MOTIONCODE_PARAMETER_I32_17 = 17u,
		MOTIONCODE_PARAMETER_I32_18 = 18u,
		MOTIONCODE_PARAMETER_I32_19 = 19u,
		MOTIONCODE_PARAMETER_I32_20 = 20u,
		MOTIONCODE_PARAMETER_I32_21 = 21u,
		MOTIONCODE_PARAMETER_I32_22 = 22u,
		MOTIONCODE_PARAMETER_I32_23 = 23u,
		MOTIONCODE_PARAMETER_I32_24 = 24u,
		MOTIONCODE_PARAMETER_I32_25 = 25u,
		MOTIONCODE_PARAMETER_I32_26 = 26u,
		MOTIONCODE_PARAMETER_I32_27 = 27u,
		MOTIONCODE_PARAMETER_I32_28 = 28u,
		MOTIONCODE_PARAMETER_I32_29 = 29u,
		MOTIONCODE_PARAMETER_I32_30 = 30u,
		MOTIONCODE_PARAMETER_I32_31 = 31u,
		MOTIONCODE_PARAMETER_I32_32 = 32u,
		MOTIONCODE_PARAMETER_I32_33 = 33u,
		MOTIONCODE_PARAMETER_I32_34 = 34u,
		MOTIONCODE_PARAMETER_I32_35 = 35u,
		MOTIONCODE_PARAMETER_I32_36 = 36u,
		MOTIONCODE_PARAMETER_I32_37 = 37u,
		MOTIONCODE_PARAMETER_I32_38 = 38u,
		MOTIONCODE_PARAMETER_I32_39 = 39u,
		MOTIONCODE_PARAMETER_I32_40 = 40u,
		MOTIONCODE_PARAMETER_I32_41 = 41u,
		MOTIONCODE_PARAMETER_I32_42 = 42u,
		MOTIONCODE_PARAMETER_I32_43 = 43u,
		MOTIONCODE_PARAMETER_I32_44 = 44u,
		MOTIONCODE_PARAMETER_I32_45 = 45u,
		MOTIONCODE_PARAMETER_I32_46 = 46u,
		MOTIONCODE_PARAMETER_I32_47 = 47u,
		MOTIONCODE_PARAMETER_I32_48 = 48u,
		MOTIONCODE_PARAMETER_I32_49 = 49u,
		MOTIONCODE_PARAMETER_I32_50 = 50u,

		MOTIONCODE_PARAMETER_UI32_01 = 51u,
		MOTIONCODE_PARAMETER_UI32_02 = 52u,
		MOTIONCODE_PARAMETER_UI32_03 = 53u,
		MOTIONCODE_PARAMETER_UI32_04 = 54u,
		MOTIONCODE_PARAMETER_UI32_05 = 55u,
		MOTIONCODE_PARAMETER_UI32_06 = 56u,
		MOTIONCODE_PARAMETER_UI32_07 = 57u,
		MOTIONCODE_PARAMETER_UI32_08 = 58u,
		MOTIONCODE_PARAMETER_UI32_09 = 59u,
		MOTIONCODE_PARAMETER_UI32_10 = 60u,

		MOTIONCODE_PARAMETER_I16_01 = 61u,
		MOTIONCODE_PARAMETER_I16_02 = 62u,
		MOTIONCODE_PARAMETER_I16_03 = 63u,
		MOTIONCODE_PARAMETER_I16_04 = 64u,
		MOTIONCODE_PARAMETER_I16_05 = 65u,
		MOTIONCODE_PARAMETER_I16_06 = 66u,
		MOTIONCODE_PARAMETER_I16_07 = 67u,
		MOTIONCODE_PARAMETER_I16_08 = 68u,
		MOTIONCODE_PARAMETER_I16_09 = 69u,
		MOTIONCODE_PARAMETER_I16_10 = 70u,

		MOTIONCODE_PARAMETER_UI16_01 = 71u,
		MOTIONCODE_PARAMETER_UI16_02 = 72u,
		MOTIONCODE_PARAMETER_UI16_03 = 73u,
		MOTIONCODE_PARAMETER_UI16_04 = 74u,
		MOTIONCODE_PARAMETER_UI16_05 = 75u,
		MOTIONCODE_PARAMETER_UI16_06 = 76u,
		MOTIONCODE_PARAMETER_UI16_07 = 77u,
		MOTIONCODE_PARAMETER_UI16_08 = 78u,
		MOTIONCODE_PARAMETER_UI16_09 = 79u,
		MOTIONCODE_PARAMETER_UI16_10 = 80u,

		MOTIONCODE_PARAMETER_I8_01 = 81u,
		MOTIONCODE_PARAMETER_I8_02 = 82u,
		MOTIONCODE_PARAMETER_I8_03 = 83u,
		MOTIONCODE_PARAMETER_I8_04 = 84u,
		MOTIONCODE_PARAMETER_I8_05 = 85u,
		MOTIONCODE_PARAMETER_I8_06 = 86u,
		MOTIONCODE_PARAMETER_I8_07 = 87u,
		MOTIONCODE_PARAMETER_I8_08 = 88u,
		MOTIONCODE_PARAMETER_I8_09 = 89u,
		MOTIONCODE_PARAMETER_I8_10 = 90u,

		MOTIONCODE_PARAMETER_UI8_01 = 91u,
		MOTIONCODE_PARAMETER_UI8_02 = 92u,
		MOTIONCODE_PARAMETER_UI8_03 = 93u,
		MOTIONCODE_PARAMETER_UI8_04 = 94u,
		MOTIONCODE_PARAMETER_UI8_05 = 95u,
		MOTIONCODE_PARAMETER_UI8_06 = 96u,
		MOTIONCODE_PARAMETER_UI8_07 = 97u,
		MOTIONCODE_PARAMETER_UI8_08 = 98u,
		MOTIONCODE_PARAMETER_UI8_09 = 99u,
		MOTIONCODE_PARAMETER_UI8_10 = 100u,
};

/*---------------- Public macros ---------------------------------------------*/

/*---------------- Public structs --------------------------------------------*/

/*---------------- Public module variable & constants declarations -----------*/

/*---------------- Public module function declarations -----------------------*/


#endif /* INC_MOTIONPARAMETERNAMES_H_ */
