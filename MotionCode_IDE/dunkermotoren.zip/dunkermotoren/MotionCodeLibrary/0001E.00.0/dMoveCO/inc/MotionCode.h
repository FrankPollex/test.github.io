/**
 *******************************************************************************
 * @cond		Project: MotionCodeLibrary @endcond
 *******************************************************************************
 * @file		MotionCode.h
 * @brief		
 * @version		Spec: 
 *******************************************************************************
 * @details	
 *******************************************************************************
 * @copyright	&copy; 2016 Dunkermotoren GmbH D-79848 Bonndorf,
 *				all rights reserved.
 *******************************************************************************
 * <h2 class="groupheader">SVN revision information</h2>
 * $Author: frank.pollex $
 * $Date: 2022-07-20 10:51:50 +0200 (Mi, 20 Jul 2022) $
 * $Revision: 501 $ <HR>
 *******************************************************************************
 */

#ifndef INC_MOTIONCODE_H_
#define INC_MOTIONCODE_H_

/*---------------- Includes --------------------------------------------------*/
#include <stdint.h>
#include <MotionCodeNotificationType.h>
/*---------------- Public defines --------------------------------------------*/

/*---------------- Public typedefs -------------------------------------------*/

/*---------------- Public enums ----------------------------------------------*/

/*---------------- Public macros ---------------------------------------------*/

/*---------------- Public structs --------------------------------------------*/

/*---------------- Public module variable & constants declarations -----------*/

/*---------------- Public module function declarations -----------------------*/
void motionCode_main(void* pd);
void motionCode_init(void);
void motionCode_notification (motion_code_notification_type_t notificationType);
#endif /* INC_MOTIONCODE_H_ */
